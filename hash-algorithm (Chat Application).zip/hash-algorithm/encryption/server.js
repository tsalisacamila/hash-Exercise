const http = require("http");
const socketIo = require("socket.io");

const server = http.createServer();
const io = socketIo(server);

const users = new Map(); 

io.on("connection", (socket) => {
  console.log(`Client ${socket.id} connected`);

  socket.emit("init", Array.from(users.entries()));

  socket.on("registeredPublicKey", (data) => {
    const { username, publicKey } = data;
    users.set(username, { socket, publicKey });
    console.log(`${username} registered with public key`);
    io.emit("newUser", { username, publicKey });
  });

  socket.on("message", (data) => {
    const { username, message, isSecret, target } = data;

    if (isSecret && target) {
      const targetUser = users.get(target);
      if (targetUser) {
        console.log(`Sending secret message from ${username} to ${target}`);
        
        targetUser.socket.emit("message", { username, message, isSecret, target });
        
        targetUser.socket.emit("secretChatStarted", { initiator: username });

        users.forEach((user, userKey) => {
          if (userKey !== username && userKey !== target) {
            user.socket.emit("message", { username, message, isSecret, target });
          }
        });
      }
    } else {
      io.emit("message", { username, message, isSecret: false });
    }
  });

  socket.on("disconnect", () => {
    console.log(`Client ${socket.id} disconnected`);
  });
});

const port = 3000;
server.listen(port, () => {
  console.log(`Server running on port ${port}`);
});
