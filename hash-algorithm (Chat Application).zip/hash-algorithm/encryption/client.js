const io = require("socket.io-client");
const readline = require("readline");
const crypto = require("crypto");

const socket = io("http://localhost:3000");

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
  prompt: "> ",
});

let targetUsername = "";
let username = "";
const users = new Map();

const { publicKey, privateKey } = crypto.generateKeyPairSync("rsa", {
  modulusLength: 2048,
  publicKeyEncoding: { type: "spki", format: "pem" },
  privateKeyEncoding: { type: "pkcs8", format: "pem" },
});

socket.on("connect", () => {
  console.log("Connected to the server");
  rl.question("Enter your username: ", (input) => {
    username = input.trim();
    console.log(`Welcome, ${username} to the chat`);

    socket.emit("registeredPublicKey", { username, publicKey });
    rl.prompt();
  });
});

socket.on("init", (keys) => {
  keys.forEach(([user, key]) => users.set(user, key));
  rl.prompt();
});

socket.on("newUser", (data) => {
  const { username, publicKey } = data;
  users.set(username, publicKey);
  console.log(`${username} joined the chat`);
  rl.prompt();
});

socket.on("secretChatStarted", ({ initiator }) => {
  targetUsername = initiator;
  rl.prompt();
});

socket.on("message", (data) => {
  const { username: sender, message, isSecret, target } = data;

  if (isSecret && target === username) {
    try {
      const decryptedMessage = crypto
        .privateDecrypt(privateKey, Buffer.from(message, "base64"))
        .toString();
      console.log(`🔒 ${sender} (secret): ${decryptedMessage}`);
    } catch (err) {
      console.log(`⚠️ Could not decrypt message from ${sender}`);
    }
  } else if (isSecret && target !== username) {
    console.log(`🔒 ${sender} : ${message}`); 
  } else {
    console.log(`${sender}: ${message}`);
  }
  rl.prompt();
});

rl.on("line", (message) => {
  if (message.trim()) {
    if (message.startsWith("!secret ")) {
      const [_, target] = message.split(" ");
      targetUsername = target;
      console.log(`Now secretly chatting with ${targetUsername}`);
    } else if (message === "!exit") {
      console.log("Exiting secret chat");
      targetUsername = "";
    } else {
      let encryptedMessage = message;
      let isSecret = false;

      if (targetUsername) {
        const targetPublicKey = users.get(targetUsername);
        if (targetPublicKey) {
          encryptedMessage = crypto
            .publicEncrypt(targetPublicKey, Buffer.from(message))
            .toString("base64");
          isSecret = true;
          
        } else {
          console.log(`⚠️ User ${targetUsername} not found`);
        }
      }

      socket.emit("message", {
        username,
        message: encryptedMessage,
        isSecret,
        target: targetUsername,
      });
    }
  }
  rl.prompt();
});

socket.on("disconnect", () => {
  console.log("Server disconnected, Exiting...");
  rl.close();
  process.exit(0);
});

rl.on("SIGINT", () => {
  console.log("\nExiting...");
  socket.disconnect();
  rl.close();
  process.exit(0);
});
